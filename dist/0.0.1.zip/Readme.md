
# Copy Gmail Email to Clipboard

I saw a bunch of friends were having issues with Gmail while trying to copy/paste email addresses.

This extension lets you double click on any email address or name in Gmail to copy the respective email address to your clipboard.

> Icon: Copy by Adam Iscrupe from The Noun Project
